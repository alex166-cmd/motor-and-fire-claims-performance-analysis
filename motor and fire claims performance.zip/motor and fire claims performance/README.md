# Project 1: Motor and Fire Claims Performance Review

**Question:** Motor loss ratios rose after the November 2023 devaluation. Where is the problem, what drives it, is repricing working, and how much rate is needed for 2027?

**Report:** `Project1_Motor_Fire_Claims_Performance_Report.docx` (12 pages, includes step-by-step guide)

## Data (simulated)

| File | Rows | Content |
|---|---|---|
| `data/monthly_performance.csv` | 720 | Month x branch x product: policies, premium, claims, expenses |
| `data/claims.csv` | 9,938 | One row per claim: cause, channel, amount, days to report and settle, status, flag |
| `data/macro_indicators.csv` | 45 | Inflation, exchange rate, policy rate |

## Run order

```bash
python scripts/01_generate_data.py       # builds the three CSV files
python scripts/02_analysis.py            # KPIs, tests, charts, outputs/results.json, outputs/kpi_tables.xlsx
python scripts/03_build_word_report.py   # builds the Word report
```

## Method in brief

1. Check the data (monthly totals must tie to the claim file).
2. Loss, expense and combined ratios, claim frequency, average claim, average premium.
3. Premium growth against inflation.
4. Break the change in loss ratio into claim numbers, claim size and premium.
5. Branch by product heat map. Settlement time by branch.
6. Welch t-test (before and after devaluation), OLS regression, one-way ANOVA.
7. 2027 rate need under three inflation scenarios.

## Main results (simulated data)

- Motor loss ratio: 57.7% (2023), 82.8% (2024), 74.5% (2025), 63.2% (Jan to Sep 2026).
- Claim size, not claim numbers, drove the rise.
- 2027 extra rate needed in the base case: about 15% motor private, 25% motor commercial.
- Zomba and Mzuzu settle claims about 9 to 13 days slower (median) than Blantyre.
